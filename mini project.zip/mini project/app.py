from flask import Flask, render_template, request, redirect, url_for, session
from flask_mysqldb import MySQL
from werkzeug.security import generate_password_hash, check_password_hash
import smtplib
from email.mime.text import MIMEText
from flask import Flask, request

app = Flask(__name__)
app.secret_key = 'your_secret_key'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'doctorappoint'

DOCTOR_ROLE='dr'
PATIENT_ROLE='p'
SUPERADMIN='super'

mysql = MySQL(app)

@app.route("/")
def main():
    return render_template('index.html')

@app.route("/home.html")
def m():
    return render_template('home.html')
@app.route("/index.html")
def i():
    return render_template('index.html')

@app.route("/about.html")
def abt():
    return render_template("about.html")


       
def home():
    if 'loggedin' in session:
        return 'You are already logged in!'
    else:
        return redirect(url_for('login'))
  
@app.route("/contactus.html", methods=['GET','POST'])
def submit_review():
    if request.method == 'POST':
        
        email = request.form['email']
        rating = request.form['message']
        
        cur = mysql.connection.cursor()
        cur.execute("INSERT INTO contact ( email, message) VALUES (%s, %s, %s, %s)", (email,rating))

        mysql.connection.commit()
        cur.close()
        return render_template('contactus.html')

    return render_template('contactus.html')

@app.route("/login.html", methods=['GET', 'POST'])
def logindr():
    if request.method == 'POST' and 'Email' in request.form and 'Password' in request.form:
        email = request.form['Email']
        password = request.form['Password']
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM doctorlogin WHERE Email = %s', (email,))
        account = cursor.fetchone()
        if account and check_password_hash(account[2], password):
            session['loggedin'] = True
            session['Email'] = account[1]
            return render_template('drdash.html')
        else:
            msg = 'Incorrect email/password!'
            return render_template('drdash.html', msg=msg)
    return render_template('login.html')

@app.route('/singup.html', methods=['GET', 'POST'])
def signupdr():
    if request.method == 'POST' and 'Email' in request.form and 'Password' in request.form:
        email = request.form['Email']
        password = generate_password_hash(request.form['Password'])
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM doctorlogin WHERE Email = %s', (email,))
        account = cursor.fetchone()
        if account:
            msg = 'Account already exists!'
            return render_template('singuppt.html', msg=msg)
        else:
            cursor.execute('INSERT INTO usertable (Email,Password) VALUES (%s, %s)', (email, password))
            mysql.connection.commit()
            msg = 'You have successfully registered!'
            return render_template('index.html', msg=msg)
    return render_template('singup.html')


@app.route("/appointment.html")
def ap():
    return render_template("appointment.html")





'''
@app.route("/login.html", methods=['GET', 'POST'])
def docl():
    
    if request.method == 'POST' and 'Email' in request.form and 'Password' in request.form:
        email = request.form['Email']
        password = request.form['Password']
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM doctorlogin WHERE Email = %s', (email,))
        account = cursor.fetchone()
        if account and check_password_hash(account[2], password):
            session['loggedin'] = True
            session['Email'] = account[1]
            return redirect(url_for('appointment'))
        else:
            msg = 'Incorrect email/password!'
            return render_template('login.html', msg=msg)
    return render_template('login.html')


 


@app.route("/singup.html", methods=['GET', 'POST'])  
def drs():
    if request.method == 'POST' and 'Email' in request.form and 'Password' in request.form:
        email = request.form['Email']
        password = generate_password_hash(request.form['Password'])
        confirm_password = request.form['ConfirmPassword']
        
        # Check if passwords match
        if password != confirm_password:
            msg = 'Passwords do not match!'
            return render_template('singup.html', msg=msg)

        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM doctorlogin WHERE Email = %s', (email,))
        account = cursor.fetchone()
        if account:
            msg = 'Account already exists!'
            return render_template('singup.html', msg=msg)
        else:
            cursor.execute('INSERT INTO doctorlogin (Email, Password) VALUES (%s, %s)', (email, password))
            mysql.connection.commit()
            msg = 'You have successfully registered!'
            return render_template('index.html', msg=msg)
    return render_template('singup.html')
  '''
@app.route('/confirmation.html')
def confirmation():
    try:
        # Connect to MySQL database
        cursor = mysql.connection.cursor()
        
       

        # Retrieve appointment details from the database
        cursor.execute("SELECT * FROM app ORDER BY Sno DESC LIMIT 1")
        appointments = cursor.fetchall()

        # Close cursor and connection
        cursor.close()
        

        # Render the confirmation page with appointment details
        return render_template('confirmation.html', appointments=appointments)
    except Exception as e:
        return str(e)

@app.route('/drdash.html')
def doctor_dashboard():
    try:
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT * FROM app ORDER BY date,time")
        appointments = cursor.fetchall()
        cursor.close()
        return render_template('drdash.html', appointments=appointments)
    except Exception as e:
        return str(e)


@app.route('/patients.html')
def patients():
    try:
        cursor = mysql.connection.cursor()
        cursor.execute("SELECT Sno, name,phone FROM app ORDER BY name")
        appointments = cursor.fetchall()
        cursor.close()
        return render_template('patients.html', appointments=appointments)
    except Exception as e:
        error_msg = f"Error fetching appointments: {str(e)}"
        print(error_msg)  # Print the error message for debugging
        return render_template('patients.html', appointments=[], error=error_msg)
import smtplib






@app.route("/consultation.html", methods=['GET', 'POST'])
def consultation():
    if request.method == 'POST':
        name = request.form.get('Name')
        age = request.form.get('Age')
        address = request.form.get('Address')
        phone = request.form.get('Phone')
        time = request.form.get('time')
        date = request.form.get('date')
        message = request.form.get('msg')
        cursor = mysql.connection.cursor()
        
        cursor.execute("SELECT * FROM app WHERE date = %s AND time = %s", (date, time))
        result = cursor.fetchone()

        if result:
            return "<script>alert('Sorry, this time slot is already reserved. Please choose another time.'); window.history.back();</script>"
        else:
         
        


        
        
         cursor.execute("INSERT INTO app (name, age, address, phone, time, date, msg) VALUES (%s, %s, %s, %s, %s, %s, %s)",
                       (name, age, address, phone, time, date, message))
         mysql.connection.commit()
        
         send_email(message)
        return render_template('home.html')
    
        
    return render_template('consultation.html')
def send_email(message):
    sender_email = 'Doccare00@gmail.com'
    recipient_email = message  # Assuming the email provided by the user is their email address
    subject = 'Appointment Confirmation'
    body = 'Your appointment with MedCare has been successfully scheduled.'

    # Create a MIMEText object
    email_message = MIMEText(body)
    email_message['Subject'] = subject
    email_message['From'] = sender_email
    email_message['To'] = recipient_email

    # Connect to the SMTP server and send the email
    with smtplib.SMTP('smtp.gmail.com', 587) as server:
        server.starttls()
        server.login(sender_email, 'yobi pgdb fyqz smfc')  # Replace 'doctorcare' with your email password
        server.sendmail(sender_email, recipient_email, email_message.as_string())
@app.route("/timeslot.html")
def ts():
    return render_template("timeslot.html")






@app.route("/loginp.html", methods=['GET', 'POST'])
def login():
    if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
        email = request.form['email']
        password = request.form['password']
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM usertable WHERE email = %s', (email,))
        account = cursor.fetchone()
        if account and check_password_hash(account[2], password):
            session['loggedin'] = True
            session['email'] = account[1]
            return render_template('home.html')
        else:
            msg = 'Incorrect email/password!'
            return render_template('loginp.html', msg=msg)
    return render_template('loginp.html')

@app.route('/singuppt.html', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
        email = request.form['email']
        password = generate_password_hash(request.form['password'])
        cursor = mysql.connection.cursor()
        cursor.execute('SELECT * FROM usertable WHERE email = %s', (email,))
        account = cursor.fetchone()
        if account:
            msg = 'Account already exists!'
            return render_template('singuppt.html', msg=msg)
        else:
            cursor.execute('INSERT INTO usertable (email, password) VALUES (%s, %s)', (email, password))
            mysql.connection.commit()
            msg = 'You have successfully registered!'
            return render_template('index.html', msg=msg)
    return render_template('singuppt.html')



@app.route('/location.html')
def loc():
    return render_template('location.html')





    

if __name__ == '__main__':
    app.run(debug=True)


if __name__ == "__main__":
    app.run(debug=True)
